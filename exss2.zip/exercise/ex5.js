let n = Number(prompt('Enter a number'));
if(n >= 0 && n < 4.5) {
    alert('Lower half of 0 - 9 range');
} else if(n <=9) {
    alert('Higher half of 0 - 9 range');
} else {
    alert('Out of 0 - 9 range');
}