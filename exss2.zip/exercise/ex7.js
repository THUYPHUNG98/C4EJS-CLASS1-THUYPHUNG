let x = Number(prompt('x ='));
let r = x%2;
if(r == 0) {
    alert(`${x} is an even number`);
} else {
    alert(`${x} is an odd number`);
}