//cau a:
setshape("rocket");
fd(100);
rt(90);
fd(100);
rt(90);
fd(100);
rt(90);
fd(100);
rt(90);
//cau b:
setshape("rocket");
fd(100);
rt(120);
fd(100);
rt(120);
fd(100);
rt(120);
//cau c:
setshape("rocket");
fd(100);
rt(72);
fd(100);
rt(72);
fd(100);
rt(72);
fd(100);
rt(72);
fd(100);
rt(72);
//cau d:
setshape("rocket");
fd(100);
rt(60);
fd(100);
rt(60);
fd(100);
rt(60);
fd(100);
rt(60);
fd(100);
rt(60);
fd(100);
rt(60);