let n = Number(prompt('Enter number of edges'));
for(let i = 0; i < n; i++) {
fd(50);
rt(360/n);
}