let n = Number(prompt('n ='));
let x = Number(prompt('x ='));
if(x < n/2) {
    alert(`${x} is in lower half of ${n}`);
} else {
    alert(`${x} is in higher half of ${n}`);
}